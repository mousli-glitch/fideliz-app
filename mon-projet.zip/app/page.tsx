export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="text-4xl font-bold">Fideliz V1</h1>
      <p>Initialisation du socle...</p>
    </main>
  )
}