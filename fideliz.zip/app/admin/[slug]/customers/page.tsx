import { createClient } from "@/utils/supabase/server"
import { notFound } from "next/navigation"
import { Mail, MessageSquare, Search, UserCheck, Calendar } from "lucide-react"
import CsvExportButton from "@/components/admin/csv-export-button" // 👈 1. IMPORT DU COMPOSANT

// --- TYPES LOCAUX POUR FORCER LE PASSAGE ---
interface Restaurant {
  id: string;
  name: string;
}

// On définit ici à quoi ressemble un gagnant pour éviter les erreurs plus bas
type WinnerFull = {
  id: string;
  first_name: string;
  email: string | null;
  phone: string;
  created_at: string;
  marketing_optin: boolean;
  game: { active_action: string; restaurant_id: string } | null;
  prize: { label: string } | null;
}

// Fonction utilitaire pour vérifier si c'est un UUID
function isUUID(str: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str)
}

export default async function CustomersPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const supabase = await createClient()

  // 1. DÉTECTION DU RESTAURANT
  let query = supabase.from("restaurants").select("id, name")
  
  if (isUUID(slug)) {
    query = query.eq("id", slug)
  } else {
    query = query.eq("slug", slug)
  }

  // ON RÉCUPÈRE LES DONNÉES BRUTES
  const { data: rawRestaurant, error: restoError } = await query.single()

  if (restoError || !rawRestaurant) {
    return notFound()
  }

  // On force TypeScript à accepter que c'est bien un Restaurant.
  const restaurant = rawRestaurant as unknown as Restaurant;

  // 2. RÉCUPÉRATION DES GAGNANTS (Clients)
  const { data: rawCustomers } = await supabase
    .from("winners")
    .select(`
      *,
      game:games!inner(active_action, restaurant_id), 
      prize:prizes(label)
    `)
    .eq("marketing_optin", true)
    .eq("game.restaurant_id", restaurant.id)
    .order("created_at", { ascending: false })

  // On force le typage des clients pour l'affichage
  const customers = rawCustomers as unknown as WinnerFull[] | null;

  return (
    <div className="min-h-screen bg-slate-50 p-8">
      <div className="max-w-6xl mx-auto">
        
        {/* EN-TÊTE */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-black text-slate-900">Portefeuille Clients 👥</h1>
            <p className="text-slate-500 mt-1 font-medium">
              Clients ayant accepté de recevoir des offres : <span className="text-blue-600 font-bold">{customers?.length || 0}</span>
            </p>
          </div>
          <div className="flex gap-3">
            {/* 👈 2. REMPLACEMENT DU BOUTON STATIQUE PAR LE COMPOSANT ACTIF */}
            <CsvExportButton 
              data={customers || []} 
              filename={`clients-${restaurant.name}.csv`} 
            />
          </div>
        </div>

        {/* ACTIONS DE CAMPAGNE */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-6 text-white shadow-lg shadow-blue-200 cursor-not-allowed opacity-90">
                <div className="flex justify-between items-start">
                    <div>
                        <h3 className="font-bold text-lg flex items-center gap-2"><MessageSquare/> Campagne SMS</h3>
                        <p className="text-blue-100 text-sm mt-1">Envoyer une promo par SMS à toute la liste.</p>
                    </div>
                    <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold backdrop-blur-sm">Bientôt</span>
                </div>
            </div>
            <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-2xl p-6 text-white shadow-lg shadow-purple-200 cursor-not-allowed opacity-90">
                <div className="flex justify-between items-start">
                    <div>
                        <h3 className="font-bold text-lg flex items-center gap-2"><Mail/> Campagne Email</h3>
                        <p className="text-purple-100 text-sm mt-1">Envoyer une newsletter à toute la liste.</p>
                    </div>
                    <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold backdrop-blur-sm">Bientôt</span>
                </div>
            </div>
        </div>

        {/* TABLEAU DES CLIENTS */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex gap-4 bg-slate-50/50">
             <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18}/>
                <input type="text" placeholder="Rechercher un client..." className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 outline-none focus:border-blue-500 transition bg-white"/>
             </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs tracking-wider">
                <tr>
                  <th className="px-6 py-4">Client</th>
                  <th className="px-6 py-4">Contact</th>
                  <th className="px-6 py-4">Jeu & Gain</th>
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4 text-right">Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {customers && customers.length > 0 ? (
                  customers.map((client) => (
                    <tr key={client.id} className="hover:bg-blue-50/50 transition">
                      <td className="px-6 py-4 font-bold text-slate-900">
                        {client.first_name || "Anonyme"}
                      </td>
                      <td className="px-6 py-4 text-slate-600">
                        <div className="flex flex-col gap-1">
                            <span className="flex items-center gap-2"><Mail size={14} className="text-slate-400"/> {client.email || "-"}</span>
                            <span className="flex items-center gap-2"><MessageSquare size={14} className="text-slate-400"/> {client.phone}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                            <span className="font-bold text-slate-800 bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded w-fit text-xs mb-1">{client.prize?.label || "Lot inconnu"}</span>
                            <span className="text-xs text-slate-400">Via {client.game?.active_action || "Jeu"}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-500">
                        <div className="flex items-center gap-2">
                            <Calendar size={14} className="text-slate-400"/> 
                            {new Date(client.created_at).toLocaleDateString('fr-FR')}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-bold border border-green-200">
                            <UserCheck size={12}/> Opt-in
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                      <div className="flex flex-col items-center justify-center gap-2">
                        <div className="bg-slate-100 p-4 rounded-full"><UserCheck size={32} className="text-slate-300"/></div>
                        <p>Aucun client n'a encore accepté de recevoir des offres.</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  )
}